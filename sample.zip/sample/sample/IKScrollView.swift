//
//  IKScrollView.swift
//  IKScrollView
//
//  Created by Ian Keen on 27/02/2016.
//  Copyright © 2016 Mustard. All rights reserved.
//

import UIKit

enum SizeMatching {
    /// Content view will keep its height and be sized to the width of the `IKScrollView`
    case width
    
    /// Content view will keep its width and be sized to the height of the `IKScrollView`
    case height
    
    /// Content view will be sized to match the width and height of the `IKScrollView`
    case both
    
    /// No resizing will happen to the content view
    case none
    
    /**
     *  Content view will be sized as required using closures for each value
     *
     *  @param width: Closure called when a width is needed
     *
     *  @return Closure called when a height is needed
     */
    case dynamic(width: () -> CGFloat, height: () -> CGFloat)
}

class IKScrollView: UIScrollView {
    //MARK: - Outlets
    @IBOutlet fileprivate var contentView: UIView?
    
    //MARK: - Properties
    @IBInspectable var sizeMatching = SizeMatching.width
    
    //MARK: - Lifecycle
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if let contentView = self.contentView {
            if (contentView.superview != self) {
                self.addSubview(contentView)
            }
            
            var size = contentView.bounds.size
            
            switch self.sizeMatching {
            case .width:    size.width = self.bounds.width
            case .height:   size.height = self.bounds.height
            case .both:     size.width = self.bounds.width; size.height = self.bounds.height
            case .dynamic(let width, let height): size.width = width(); size.height = height()
            case .none:     break
            }
            
            contentView.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: size)
            self.contentSize = size
        }
    }
}
